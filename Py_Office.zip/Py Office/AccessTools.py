import pyodbc
import os

folder_name = "Database Folder"
if not os.path.exists(folder_name):
    os.makedirs(folder_name)


def open_database(filename,ignoreError = False):
    try:
        connection_str = 'DRIVER={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=Database Folder/' + filename
        database = pyodbc.connect(connection_str)
        return database
    except pyodbc.Error as e:
        if ignoreError == False:
            print(f"Error connecting to database: {e}")
        return None

def close_database(database,ignoreError = False):
    try:
        database.close()
    except pyodbc.Error as e:
        if ignoreError == False:
            print(f"Error connecting to database: {e}")

def return_table(database,tableName,ignoreError = False):
    try:
        cursor = database.cursor()
        cursor.execute(f"SELECT * FROM {tableName}")
        return cursor.fetchall()
    except pyodbc.Error as e:
        if ignoreError == False:
            print(f"Error connecting to database: {e}")
            return None

def return_row(database,tableName,rowNum,ignoreError = False):
    try:
        cursor = database.cursor()
        cursor.execute(f"SELECT * FROM {tableName} WHERE {tableName}ID = {rowNum}")
        return cursor.fetchall()
    except pyodbc.Error as e:
        if ignoreError == False:
            print(f"Error connecting to database: {e}")
        return None

def return_column(database,tableName,columnName,ignoreError = False):
    try:
        cursor = database.cursor()
        cursor.execute(f"SELECT {columnName} FROM {tableName} ")
        return cursor.fetchall()
    except pyodbc.Error as e:
        if ignoreError == False:
            print(f"Error connecting to database: {e}")
        return None

def return_value(database,tableName,rowNum,columnName,ignoreError = False):
    try:
        cursor = database.cursor()
        cursor.execute(f"SELECT {columnName} FROM {tableName} WHERE {tableName}ID = {rowNum}")
        return cursor.fetchall()
    except pyodbc.Error as e:
        if ignoreError == False:
            print(f"Error connecting to database: {e}")
        return None

def set_value(database,tableName,rowNum,columnName,value,ignoreError = False):
    try:
        cursor = database.cursor()
        cursor.execute(f"UPDATE {tableName} SET {columnName} = {value} WHERE {tableName}ID = {rowNum}")
        database.commit()
    except pyodbc.Error as e:
        if ignoreError == False:
            print(f"Error connecting to database: {e}")

def insert_value(database,tableName,rowNum,columnName,value,ignoreError = False):
    try:
        cursor = database.cursor()
        cursor.execute(f"INSERT INTO {tableName}( [{columnName}].Value ) VALUES ('{value}') WHERE {tableName}ID = {rowNum}")
        database.commit()
    except pyodbc.Error as e:
        if ignoreError == False:
            print(f"Error connecting to database: {e}")
