import openpyxl

def create_workbook():
    workbook = openpyxl.Workbook()
    return workbook

def open_workbook(fileName):
    workbook = openpyxl.load_workbook(fileName)
    return workbook

def close_workbook(workbook):
    workbook.close()
    
def save_workbook(workbook,filename):
    workbook.save(filename)

def copy_cell(workbook,cell):
    value = workbook.active[cell].value
    return value

def paste_cell(workbook,cell,value):
    workbook.active[cell].value = value
    
def copy_range(workbook,startCell,endCell):
    values = workbook.active[f"{startCell}:{endCell}"]
    values = tuple(item.value for sublist in values for item in sublist)
    return values

def paste_range(workbook,startCell,endCell,values):
    cellRange = workbook.active[f"{startCell}:{endCell}"]
    cellRange = tuple(item for sublist in cellRange for item in sublist)
    if len(cellRange) == len(values):
        for cell in range(len(cellRange)):
            cellRange[cell].value = values[cell]
